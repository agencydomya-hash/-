/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Stethoscope, CheckCircle, Clock, Calendar, ShieldCheck, Mail, Phone, Globe, ChevronDown, Award } from 'lucide-react';
import { DoctorSubmission, DiagnosisOutput } from '../types';

interface BookingFormProps {
  diagnosisRef: DiagnosisOutput | null;
  onSuccess: () => void;
}

export default function BookingForm({ diagnosisRef, onSuccess }: BookingFormProps) {
  const [form, setForm] = useState({
    name: '',
    specialty: '',
    clinicName: '',
    phone: '',
    email: '',
    socialLink: '',
    goal: 'جذب مرضى حقيقيين وزيادة تعاقدات العيادة'
  });

  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  // Auto-fill form if there is a diagnosis completed
  useEffect(() => {
    if (diagnosisRef) {
      setForm(prev => ({
        ...prev,
        name: diagnosisRef.patientName || '',
        specialty: diagnosisRef.specialty || '',
        goal: 'بناء البراند الطبي الموصى به في الروشتة الذكية'
      }));
    }
  }, [diagnosisRef]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.specialty || !form.phone) {
      setError("برجاء ملء الحقول الإجبارية: الاسم، التخصص، ورقم الهاتف.");
      return;
    }

    setError('');
    setLoading(true);

    try {
      const response = await fetch('/api/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          diagnosisId: diagnosisRef ? diagnosisRef.id : null
        })
      });

      if (!response.ok) {
        throw new Error("حدث خطأ أثناء إرسال بيانات الاستشارة.");
      }

      setSubmitted(true);
      if (onSuccess) {
        onSuccess();
      }
    } catch (err: any) {
      setError(err.message || "فشل الاتصال بالخادم. يرجى مراجعة شبكة الإنترنت والمحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white py-20 border-b border-gray-200" id="booking-section">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center mb-12 space-y-3" dir="rtl">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-100 text-[#FF8C00] rounded-full text-sm font-semibold">
            <Calendar className="w-4 h-4" />
            <span>جدولة الاستشارة المجانية</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-sans font-bold text-[#1A2B5B]">
            احجز استشارة براندنج طبي وتصوير مجانية 📞
          </h2>
          <p className="text-gray-600 max-w-xl mx-auto text-sm sm:text-base">
            سجل بياناتك الطبية الآن، ليقوم مستشار تسويق من فريق دومايا بالاتصال بك وترتيب موعد لزيارة العيادة ودراسة حالتك الرقمية بالتفصيل.
          </p>
        </div>

        {submitted ? (
          /* Submission Receipt Box */
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-emerald-50/50 border-2 border-emerald-500/20 p-8 sm:p-10 rounded-2xl text-center space-y-6"
            dir="rtl"
            id="booking-success"
          >
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
              <CheckCircle className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-emerald-950">تم حجز استشارتك الطبية التسويقية بنجاح! 🎉</h3>
              <p className="text-gray-600 text-sm max-w-md mx-auto">
                شكراً دكتور <span className="font-bold text-[#1A2B5B]">{form.name}</span>. تم استلام ملفك وتحويله للجنة الفنية بوكالة دومايا لفحصه ومراجعته.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white p-4 rounded-xl border border-emerald-100 text-right text-xs max-w-lg mx-auto">
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-orange-500" />
                <div>
                  <span className="text-gray-400 block">وقت الاتصال المتوقع:</span>
                  <span className="font-bold text-gray-800">خلال 24 ساعة عمل</span>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <div>
                  <span className="text-gray-400 block">نوع الملف:</span>
                  <span className="font-bold text-emerald-900">سرية بيانات الطبيب مضمونة 🔒</span>
                </div>
              </div>
            </div>

            <p className="text-xs text-gray-400">
              ممثلو مكتب مصر (+20109) أو مكتب السعودية (+9665) سيتواصلون معك عبر الهاتف أو الواتساب مباشرة.
            </p>
          </motion.div>
        ) : (
          /* Form layout */
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#f8fafc] rounded-2xl shadow-xl border border-gray-200/60 p-6 sm:p-10 text-right"
            dir="rtl"
            id="booking-form-wrapper"
          >
            {diagnosisRef && (
              <div className="mb-6 p-4 bg-orange-50 border-r-4 border-[#FF8C00] text-orange-950 rounded-lg text-xs sm:text-sm font-semibold flex items-center gap-2">
                <Award className="w-5 h-5 text-orange-600" />
                <span>تم الربط بنجاح مع الروشتة الذكية رقم {diagnosisRef.id}. بيانات الاسم والتخصص معبأة تلقائياً دكتور!</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <div className="p-4 bg-red-50 border-r-4 border-red-500 text-red-700 text-sm rounded-lg">
                  {error}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Doctor Name */}
                <div className="space-y-2">
                  <label className="block text-xs sm:text-sm font-bold text-gray-700">
                    اسم الطبيب الكريم <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="name"
                    required
                    placeholder="مثال: د. هاني الرفاعي"
                    value={form.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white focus:ring-2 focus:ring-[#FF8C00] focus:border-[#FF8C00] outline-none text-gray-800 text-sm"
                  />
                </div>

                {/* Specialty */}
                <div className="space-y-2">
                  <label className="block text-xs sm:text-sm font-bold text-gray-700">
                    التخصص الدقيق <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="specialty"
                    required
                    placeholder="مثال: جراحة التجميل والترميم"
                    value={form.specialty}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white focus:ring-2 focus:ring-[#FF8C00] focus:border-[#FF8C00] outline-none text-gray-800 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Clinic / Hospital Name */}
                <div className="space-y-2">
                  <label className="block text-xs sm:text-sm font-bold text-gray-700">اسم العيادة أو المركز الطبي</label>
                  <input
                    type="text"
                    name="clinicName"
                    placeholder="مثال: مجمع عيادات الرفاعي لطب المفاصل"
                    value={form.clinicName}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white focus:ring-2 focus:ring-[#FF8C00] focus:border-[#FF8C00] outline-none text-gray-800 text-sm"
                  />
                </div>

                {/* Phone Number with country indicator */}
                <div className="space-y-2">
                  <label className="block text-xs sm:text-sm font-bold text-gray-700">
                    رقم الهاتف للاتصال والواتساب <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="tel"
                      name="phone"
                      required
                      placeholder="مثال: +201090121000 أو +9665..."
                      value={form.phone}
                      onChange={handleInputChange}
                      className="w-full px-10 py-3 rounded-xl border border-gray-200 bg-white focus:ring-2 focus:ring-[#FF8C00] focus:border-[#FF8C00] outline-none text-gray-800 text-sm text-left"
                      dir="ltr"
                    />
                    <Phone className="w-4 h-4 text-gray-400 absolute top-1/2 right-3.5 -translate-y-1/2" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Email Address */}
                <div className="space-y-2">
                  <label className="block text-xs sm:text-sm font-bold text-gray-700">البريد الإلكتروني</label>
                  <div className="relative">
                    <input
                      type="email"
                      name="email"
                      placeholder="doctor@example.com"
                      value={form.email}
                      onChange={handleInputChange}
                      className="w-full px-10 py-3 rounded-xl border border-gray-200 bg-white focus:ring-2 focus:ring-[#FF8C00] focus:border-[#FF8C00] outline-none text-gray-800 text-sm text-left"
                      dir="ltr"
                    />
                    <Mail className="w-4 h-4 text-gray-400 absolute top-1/2 right-3.5 -translate-y-1/2" />
                  </div>
                </div>

                {/* Current Social Link */}
                <div className="space-y-2">
                  <label className="block text-xs sm:text-sm font-bold text-gray-700">رابط صفحتك الحالية إن وجد</label>
                  <div className="relative">
                    <input
                      type="url"
                      name="socialLink"
                      placeholder="https://facebook.com/doctor.page"
                      value={form.socialLink}
                      onChange={handleInputChange}
                      className="w-full px-10 py-3 rounded-xl border border-gray-200 bg-white focus:ring-2 focus:ring-[#FF8C00] focus:border-[#FF8C00] outline-none text-gray-800 text-sm text-left"
                      dir="ltr"
                    />
                    <Globe className="w-4 h-4 text-gray-400 absolute top-1/2 right-3.5 -translate-y-1/2" />
                  </div>
                </div>
              </div>

              {/* Selection of Marketing Goals */}
              <div className="space-y-2">
                <label className="block text-xs sm:text-sm font-bold text-gray-700">الهدف الأبرز للبراندينج وعيادتك</label>
                <div className="relative">
                  <select
                    name="goal"
                    value={form.goal}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 bg-white focus:ring-2 focus:ring-[#FF8C00] focus:border-[#FF8C00] outline-none text-gray-800 text-sm appearance-none font-medium"
                  >
                    <option value="جذب مرضى حقيقيين وزيادة تعاقدات العيادة">جذب مرضى حقيقيين وزيادة حجوزات العيادة 📈</option>
                    <option value="تثبيت الهيبة والمصداقية العلمية ومواجهة المنافسين">تثبيت المصداقية العلمية ومواجهة المنافسين 🛡️</option>
                    <option value="بناء براند متكامل وتصوير Reels احترافي بالعيادة">بناء براند متكامل وتصوير Reels احترافي بالعيادة 🎥</option>
                    <option value="توسيع الانتشار والوصول لصفحات التلفزيون أو السفر الطبي">توسيع الانتشار والوصول للظهور الإعلامي المتميز 🌟</option>
                    <option value="بناء البراند الطبي الموصى به في الروشتة الذكية">بناء البراند الطبي الموصى به في الروشتة الذكية 📝</option>
                  </select>
                  <ChevronDown className="w-4 h-4 text-gray-400 absolute top-1/2 left-3.5 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              <div className="pt-4 text-left">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full sm:w-auto px-10 py-4 bg-[#1A2B5B] hover:bg-[#101b3d] text-white font-bold rounded-xl transition duration-300 shadow-xl shadow-blue-900/10 flex items-center justify-center gap-2 text-base"
                  id="submit-booking-form"
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                      <span>جاري إرسال البيانات وتأمين الملف...</span>
                    </>
                  ) : (
                    <>
                      <Stethoscope className="w-5 h-5 text-orange-400" />
                      <span>تقديم طلب الحجز والفحص المجاني</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        )}

      </div>
    </div>
  );
}
